//
// Created by Simon Gonzalez on 3/21/23.
//

#include "TileMap.h"
#include "stdafx.h"

TileMap::TileMap() {

}

TileMap::~TileMap() {

}

void TileMap::addTile(int x, int y) {

}

void TileMap::removeTile(int x, int y) {

}

void TileMap::update() {

}

void TileMap::render() {

}

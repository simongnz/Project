#include <cstdlib>
#include <ctime>
#include<time.h>
#include<iostream>

//precompiled header to lower loading time when running the code

#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
#include <SFML/Network.hpp>

// SFML libraries